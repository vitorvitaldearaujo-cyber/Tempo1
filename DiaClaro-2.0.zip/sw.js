const CACHE='diaclaro-shell-v2';
const SHELL=['./DiaClaro.html','./manifest.json'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL).catch(()=>{})).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{if(e.request.method!=='GET')return;e.respondWith(fetch(e.request).then(r=>{const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy)).catch(()=>{});return r}).catch(()=>caches.match(e.request).then(r=>r||caches.match('./DiaClaro.html'))))});
self.addEventListener('push',e=>{let d={title:'DiaClaro',body:'Você tem um novo alerta meteorológico.',url:'./DiaClaro.html'};try{if(e.data)d={...d,...e.data.json()}}catch{try{if(e.data)d.body=e.data.text()}catch{}}
e.waitUntil(self.registration.showNotification(d.title,{body:d.body,icon:d.icon||undefined,tag:d.tag||'diaclaro-alert',renotify:true,data:{url:d.url}}))});
self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{for(const c of cs){if('focus' in c)return c.focus()}return clients.openWindow(e.notification.data?.url||'./DiaClaro.html')}))});
